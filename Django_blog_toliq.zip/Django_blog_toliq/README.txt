DJANGO BLOG - TO'LIQ VERSIYA

FUNKSIYALAR:
- Bosh sahifa
- Post yaratish
- Postni batafsil o'qish
- Postni tahrirlash
- Postni o'chirish
- Kategoriya
- Nashr etilgan/nashr etilmagan holati
- Ko'rishlar soni
- TOP 5 ommabop post
- Post qidirish
- Izoh qoldirish
- Admin panel
- Oxirgi 3 ta post
- Kitob/jurnal uslubidagi dizayn

O'RNATISH:

1. Virtual muhitni yoqing:
   muhit\Scripts\activate

2. Django o'rnating:
   pip install django

3. Migration:
   python manage.py makemigrations
   python manage.py migrate

4. Admin:
   python manage.py createsuperuser

5. Server:
   python manage.py runserver

SAYT:
http://127.0.0.1:8000/

ADMIN:
http://127.0.0.1:8000/admin/

MUHIM:
Agar sizda allaqachon ma'lumotlar bor bo'lsa, ushbu paketdagi
db.sqlite3 mavjud bo'lmagani sababli eski db.sqlite3 faylingizni
o'chirmang. Faqat kod fayllarini o'zingizning loyihangizga qo'ying.
