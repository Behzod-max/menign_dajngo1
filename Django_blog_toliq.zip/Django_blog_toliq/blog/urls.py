from django.urls import path

from . import views

urlpatterns = [
    path("", views.bosh_sahifa, name="bosh_sahifa"),

    path(
        "post/<int:post_id>/",
        views.post_batafsil,
        name="post_batafsil",
    ),

    path(
        "post-yaratish/",
        views.post_yaratish,
        name="post_yaratish",
    ),

    path(
        "post/<int:post_id>/tahrirlash/",
        views.post_tahrirlash,
        name="post_tahrirlash",
    ),

    path(
        "post/<int:post_id>/ochirish/",
        views.post_ochirish,
        name="post_ochirish",
    ),

    path(
        "biz-haqimizda/",
        views.biz_haqimizda,
        name="biz_haqimizda",
    ),

    path("aloqa/", views.aloqa, name="aloqa"),

    path(
        "salom/<str:ism>/",
        views.salomlash,
        name="salomlash",
    ),

    path(
        "ommabop/",
        views.ommabop_postlar,
        name="ommabop",
    ),

    path(
        "qidiruv/",
        views.qidiruv,
        name="qidiruv",
    ),
]
