from django.db import models


class Post(models.Model):
    KATEGORIYA = [
        ("texnologiya", "Texnologiya"),
        ("hayot", "Hayot"),
        ("sport", "Sport"),
    ]

    sarlavha = models.CharField(max_length=200)
    matn = models.TextField()
    muallif = models.CharField(max_length=100)
    yaratilgan_sana = models.DateTimeField(auto_now_add=True)
    yangilangan_sana = models.DateTimeField(auto_now=True)
    nashr_etilgan = models.BooleanField(default=True)
    korildi = models.IntegerField(default=0)
    kategoriya = models.CharField(
        max_length=50,
        choices=KATEGORIYA,
        default="texnologiya",
    )

    def __str__(self):
        return self.sarlavha


class Izoh(models.Model):
    post = models.ForeignKey(
        Post,
        on_delete=models.CASCADE,
        related_name="izohlar",
    )
    ism = models.CharField(max_length=100)
    matn = models.TextField()
    yaratilgan_sana = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.ism} - {self.post.sarlavha}"
