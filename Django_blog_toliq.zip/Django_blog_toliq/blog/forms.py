from django import forms
from .models import Post


class PostForma(forms.ModelForm):
    class Meta:
        model = Post
        fields = [
            "sarlavha",
            "matn",
            "muallif",
            "kategoriya",
            "nashr_etilgan",
        ]
        labels = {
            "sarlavha": "Sarlavha",
            "matn": "Matn",
            "muallif": "Muallif",
            "kategoriya": "Kategoriya",
            "nashr_etilgan": "Nashr etilgan",
        }
        widgets = {
            "sarlavha": forms.TextInput(
                attrs={"placeholder": "Post sarlavhasi"}
            ),
            "matn": forms.Textarea(
                attrs={"placeholder": "Post matnini yozing...", "rows": 10}
            ),
            "muallif": forms.TextInput(
                attrs={"placeholder": "Muallif ismi"}
            ),
        }
