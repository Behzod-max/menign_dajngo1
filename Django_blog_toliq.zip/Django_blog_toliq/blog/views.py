from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render

from .forms import PostForma
from .models import Izoh, Post


def bosh_sahifa(request):
    postlar = Post.objects.filter(
        nashr_etilgan=True
    ).order_by("-yaratilgan_sana")

    oxirgi_postlar = Post.objects.filter(
        nashr_etilgan=True
    ).order_by("-yaratilgan_sana")[:3]

    return render(
        request,
        "blog/bosh.html",
        {
            "postlar": postlar,
            "oxirgi_postlar": oxirgi_postlar,
        },
    )


def post_batafsil(request, post_id):
    post = get_object_or_404(Post, id=post_id)

    if request.method == "POST":
        ism = request.POST.get("ism", "").strip()
        matn = request.POST.get("matn", "").strip()

        if ism and matn:
            Izoh.objects.create(
                post=post,
                ism=ism,
                matn=matn,
            )
            return redirect("post_batafsil", post_id=post.id)

    post.korildi += 1
    post.save(update_fields=["korildi"])

    izohlar = post.izohlar.all().order_by("-yaratilgan_sana")

    return render(
        request,
        "blog/post_batafsil.html",
        {
            "post": post,
            "izohlar": izohlar,
        },
    )


def post_yaratish(request):
    if request.method == "POST":
        forma = PostForma(request.POST)
        if forma.is_valid():
            forma.save()
            return redirect("bosh_sahifa")
    else:
        forma = PostForma()

    return render(
        request,
        "blog/post_yaratish.html",
        {"forma": forma},
    )


def post_tahrirlash(request, post_id):
    post = get_object_or_404(Post, id=post_id)

    if request.method == "POST":
        forma = PostForma(request.POST, instance=post)
        if forma.is_valid():
            forma.save()
            return redirect("post_batafsil", post_id=post.id)
    else:
        forma = PostForma(instance=post)

    return render(
        request,
        "blog/post_tahrirlash.html",
        {
            "forma": forma,
            "post": post,
        },
    )


def post_ochirish(request, post_id):
    post = get_object_or_404(Post, id=post_id)

    if request.method == "POST":
        post.delete()
        return redirect("bosh_sahifa")

    return render(
        request,
        "blog/post_ochirish.html",
        {"post": post},
    )


def biz_haqimizda(request):
    return render(request, "blog/biz_haqimizda.html")


def aloqa(request):
    return render(request, "blog/aloqa.html")


def salomlash(request, ism):
    return HttpResponse(f"Salom, {ism}!")


def ommabop_postlar(request):
    postlar = Post.objects.filter(
        nashr_etilgan=True
    ).order_by("-korildi")[:5]

    return render(
        request,
        "blog/ommabop.html",
        {"postlar": postlar},
    )


def qidiruv(request):
    soz = request.GET.get("q", "").strip()

    if soz:
        postlar = Post.objects.filter(
            sarlavha__icontains=soz,
            nashr_etilgan=True,
        ).order_by("-yaratilgan_sana")
    else:
        postlar = Post.objects.none()

    return render(
        request,
        "blog/qidiruv.html",
        {
            "postlar": postlar,
            "soz": soz,
        },
    )
