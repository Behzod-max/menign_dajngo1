from django.contrib import admin

from .models import Izoh, Post


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = (
        "sarlavha",
        "muallif",
        "kategoriya",
        "nashr_etilgan",
        "korildi",
        "yaratilgan_sana",
        "yangilangan_sana",
    )
    list_filter = (
        "kategoriya",
        "nashr_etilgan",
        "yaratilgan_sana",
    )
    search_fields = (
        "sarlavha",
        "matn",
        "muallif",
    )


@admin.register(Izoh)
class IzohAdmin(admin.ModelAdmin):
    list_display = (
        "ism",
        "post",
        "yaratilgan_sana",
    )
    list_filter = ("yaratilgan_sana",)
    search_fields = ("ism", "matn")
